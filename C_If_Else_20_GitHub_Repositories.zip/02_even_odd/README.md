# Even or Odd
Checks whether an entered number is even or odd.

## Language
C

## Concepts
- if
- else if
- else

## Run
```bash
gcc main.c -o main
./main
```
