# Smallest of Three Numbers
Finds the smallest among three numbers.

## Language
C

## Concepts
- if
- else if
- else

## Run
```bash
gcc main.c -o main
./main
```
