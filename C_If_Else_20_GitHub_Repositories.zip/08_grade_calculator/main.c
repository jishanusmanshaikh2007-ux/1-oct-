#include <stdio.h>

int main() {
    float marks;

    printf("Enter marks (0-100): ");
    scanf("%f", &marks);

    if (marks >= 90)
        printf("Grade A\n");
    else if (marks >= 75)
        printf("Grade B\n");
    else if (marks >= 60)
        printf("Grade C\n");
    else if (marks >= 40)
        printf("Grade D\n");
    else
        printf("Fail\n");

    return 0;
}
