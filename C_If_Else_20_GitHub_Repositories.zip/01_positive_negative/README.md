# Positive, Negative or Zero
A beginner C program using `if`, `else if`, and `else` to check a number.

## Language
C

## Concepts
- if
- else if
- else

## Run
```bash
gcc main.c -o main
./main
```
