# Largest of Two Numbers
Finds the largest of two entered numbers.

## Language
C

## Concepts
- if
- else if
- else

## Run
```bash
gcc main.c -o main
./main
```
